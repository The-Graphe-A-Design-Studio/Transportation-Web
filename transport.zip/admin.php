<?php
    header("location: login");
?>